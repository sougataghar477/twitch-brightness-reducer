# twitch-brightness-reducer
Reduces brightness of video player on twitch
